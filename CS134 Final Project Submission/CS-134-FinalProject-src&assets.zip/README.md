Put the bin and src folders in your openFrameworks project folder (the one with the .sln file). Overwrite if needed. .obj and .ma files are in bin/data/geo.
